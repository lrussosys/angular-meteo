import {ConverterPipe } from './converter.pipe';

describe('ConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new ConverterPipe();
    expect(pipe).toBeTruthy();
  });
});
